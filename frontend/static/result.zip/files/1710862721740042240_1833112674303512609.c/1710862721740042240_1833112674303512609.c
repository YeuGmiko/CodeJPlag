#include <stdio.h>
#include <stdlib.h>
typedef struct c
{
    int x;
    struct c *r;
} st;

int main()
{

    st *al = malloc(sizeof(st));
    st *bl = malloc(sizeof(st));
    st *ar = al, *br = bl;
    int mid;
    // scanf("%d", &mid);
    while (scanf("%d", &mid) != EOF)
    {
        if (mid == -1)
            break;
        st *m = malloc(sizeof(st));
        m->x = mid;
        ar->r = m;
        ar = m;
    }
    while (scanf("%d", &mid) != EOF)
    {
        if (mid == -1)
            break;
        st *m = malloc(sizeof(st));
        m->x = mid;
        br->r = m;
        br = m;
    }
    ar->r = br->r = NULL;
    st *new = malloc(sizeof(st));
    new->r = NULL;
    st *newr = new;
    al = al->r, bl = bl->r;
  
    while (al && bl)
    {
            
            if (al->x == bl->x)
            {
            
                newr->r = bl;
                newr = bl;
                al = al->r;
                bl = bl->r;
            }
            else if (al->x > bl->x)
            {

                bl = bl->r;
            }
            else
            {
                al = al->r;
            }
        
      
    }
    newr->r = NULL;
    new = new->r;
    if (new)
        while (new)
        {
            printf("%d ", new->x);
            new = new->r;
        }
    else
        printf("NULL");
    return 0;
}