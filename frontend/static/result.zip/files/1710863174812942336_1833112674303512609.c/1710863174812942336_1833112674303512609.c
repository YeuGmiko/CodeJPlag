#include <stdio.h>
#include <stdlib.h>
typedef struct
{
    int *m;
    int len;
} shu;
void ru(shu *a)
{
    a->m = (int *)malloc(1000000 * sizeof(int));
    a->len = 0;
}
void du(shu *a, int n)
{
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &a->m[i]);
        a->len++;
    }
}
void tong(shu *a, shu *b, shu *c)
{
    int i = 0, j = 0;
    while (i < a->len && j < b->len)
    {
        if (a->m[i] == b->m[j])
        {
            c->m[c->len++] = a->m[i];
            i++;
            j++;
        }
        else if (a->m[i] < b->m[j])
        {
            i++;
        }
        else
        {
            j++;
        }
    }
}

int main()
{
    shu a, b, c;
    ru(&a);
    ru(&b);
    ru(&c);
    while (1)
    {
        int x;
        scanf("%d", &x);
        if (x == -1)
            break;
        a.m[a.len++] = x;
    }
    while (1)
    {
        int y;
        scanf("%d", &y);
        if (y == -1)
            break;
        b.m[b.len++] = y;
    }
    tong(&a, &b, &c);
    if (c.len == 0)
    {
        printf("NULL");
    }
    else
    {
        printf("%d", c.m[0]);
        for (int i = 1; i < c.len; i++)
            printf(" %d", c.m[i]);
    }
    return 0;
}