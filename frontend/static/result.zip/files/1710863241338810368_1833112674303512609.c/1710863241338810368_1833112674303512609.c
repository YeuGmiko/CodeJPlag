#include<stdio.h>
#include<stdlib.h>
typedef struct list{
	int data;
	struct list *next;
}list;
void set(list *head)
{
	if(head==NULL)
	{
		printf("NULL");
	}else
	while(head)
	{
		printf("%d",head->data);
		head=head->next;
		if(head)
		printf(" ");
		
	}
}
list *Greatlist()
{
	list *t,*p,*head=NULL;
	int n;
	while(1)
	{
		scanf("%d",&n);
		if(n==-1)
		break;
		t=(list*)malloc(sizeof(struct list));
		t->data=n;
		t->next=NULL;
		if(head==NULL)
		head=t;
		else
		{
			p->next=t;
		}
		p=t;
	 }return head;
}
void hed(list *s1,list *s2)
{
	list *s3=NULL,*t,*p;
	while(s1&&s2){
	if(s1->data==s2->data)
	{
		t=(list *)malloc(sizeof(struct list));
		t->data=s1->data;
		t->next=NULL;
		if(s3==NULL)
		s3=t;
		else
		p->next=t;
		p=t;
		s1=s1->next;
		s2=s2->next;
	}else if(s1->data<s2->data)
	{
		s1=s1->next;
	}
	else{
	s2=s2->next;}
}
	set(s3);
}
int main()
{
	list *s1=Greatlist();
	list *s2=Greatlist();
	hed(s1,s2);
}
