#include <stdio.h>
#include <stdlib.h>

typedef struct Node
{
    int data;
    struct Node *next;
} Node;

typedef struct
{
    Node *head, *tail;
} List;

void init(List *p)
{
    p->head = p->tail = NULL;
}

void add(List *li, int val)
{
    Node *tmp = (Node *)malloc(sizeof(Node));
    tmp->data = val;
    tmp->next = NULL;

    if (li->head == NULL)
    {
        li->head = tmp;
    }
    else
    {
        li->tail->next = tmp;
    }
    li->tail = tmp;
}

void print(List *li)
{
    if (li->head == NULL)
    {
        printf("NULL\n");
        return;
    }

    Node *it = li->head;
    while (it)
    {
        printf("%d", it->data);
        if (it->next != NULL)
        {
            printf(" ");
        }
        it = it->next;
    }
    printf("\n");
}

void f(List *li1, List *li2, List *li3)
{
    Node *it1 = li1->head;
    Node *it2 = li2->head;

    while (it1 != NULL && it2 != NULL)
    {
        if (it1->data < it2->data)
        {
            it1 = it1->next;
        }
        else if (it1->data > it2->data)
        {
            it2 = it2->next;
        }
        else
        {
            add(li3, it1->data);
            it1 = it1->next;
            it2 = it2->next;
        }
    }
}

void freeList(List *li)
{
    Node *current = li->head;
    Node *next;

    while (current)
    {
        next = current->next;
        free(current);
        current = next;
    }
    li->head = li->tail = NULL;
}

int main()
{
    List li1, li2, li3;
    init(&li1);
    init(&li2);
    init(&li3);
    int n;
    while (scanf("%d", &n) && n != -1)
    {
        add(&li1, n);
    }

    while (scanf("%d", &n) && n != -1)
    {
        add(&li2, n);
    }
    f(&li1, &li2, &li3);
    print(&li3);
    freeList(&li1);
    freeList(&li2);
    freeList(&li3);

    return 0;
}