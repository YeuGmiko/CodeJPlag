#include <stdio.h>
int b[10000000], a[10000000], c[10000000];
int main()
{
    int k, i = 0, j = 0, q = 0;
    while (1)
    {
        scanf("%d", &a[i]);
        if (a[i] == -1)
            break;
        i++;
    }
    while (1)
    {
        scanf("%d", &b[j]);
        if (b[j] == -1)
            break;
        j++;
    }
    int p1 = 0, p2 = 0;
    while (p1 < i && p2 < j)
    {
        if (a[p1] == b[p2])
        {
            c[q++] = a[p1];
            p1++;
            p2++;
        }
        else if (a[p1] < b[p2])
        {
            p1++;
        }
        else
        {
            p2++;
        }
    }
    if (q)
    {
        for (i = 0; i < q - 1; i++)
            printf("%d ", c[i]);
        printf("%d", c[i]);
    }
    else
        printf("NULL");
}