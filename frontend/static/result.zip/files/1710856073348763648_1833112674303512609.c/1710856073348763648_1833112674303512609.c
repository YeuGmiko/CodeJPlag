#include <stdio.h>
#include <stdlib.h>

// 链表节点结构体
typedef struct ListNode {
    int data;
    struct ListNode *next;
} ListNode;

// 创建链表节点
ListNode *createNode(int data) {
    ListNode *newNode = (ListNode *)malloc(sizeof(ListNode));
    newNode->data = data;
    newNode->next = NULL;
    return newNode;
}

// 创建链表
ListNode *createList() {
    int num;
    scanf("%d", &num);
    if (num == -1) {
        return NULL;
    }
    ListNode *head = createNode(num);
    ListNode *tail = head;
    scanf("%d", &num);
    while (num!= -1) {
        ListNode *newNode = createNode(num);
        tail->next = newNode;
        tail = newNode;
        scanf("%d", &num);
    }
    return head;
}

// 求两个链表的交集
ListNode *intersection(ListNode *list1, ListNode *list2) {
    ListNode *head = NULL;
    ListNode *tail = NULL;
    ListNode *p = list1;
    ListNode *q = list2;
    while (p!= NULL && q!= NULL) {
        if (p->data < q->data) {
            p = p->next;
        } else if (p->data > q->data) {
            q = q->next;
        } else {
            if (head == NULL) {
                head = createNode(p->data);
                tail = head;
            } else {
                ListNode *newNode = createNode(p->data);
                tail->next = newNode;
                tail = newNode;
            }
            p = p->next;
            q = q->next;
        }
    }
    return head;
}

// 输出链表
void printList(ListNode *head) {
    if (head == NULL) {
        printf("NULL");
        return;
    }
    ListNode *p = head;
    while (p!= NULL) {
        printf("%d", p->data);
        if (p->next!= NULL) {
            printf(" ");
        }
        p = p->next;
    }
    printf("\n");
}

int main() {
    ListNode *list1 = createList();
    ListNode *list2 = createList();
    ListNode *intersectList = intersection(list1, list2);
    printList(intersectList);
    return 0;
}
