#include <stdio.h>
#include <stdlib.h>
typedef struct c
{
    int x;
    struct c *e;
} st;

int main()
{
    
    st *ar=malloc(sizeof(st));
    st *br=malloc(sizeof(st));
    st *aa=ar,*bb=br;
    int mid;
    
    while (scanf("%d",&mid)!=EOF)
    {
        if(mid==-1)
        break;
        st *z=malloc(sizeof(st));
        z->x=mid;
        aa->e=z;
        aa=z;
    }
    while (scanf("%d",&mid)!=EOF)
    {
        if(mid==-1)
        break;
        st *z=malloc(sizeof(st));
        z->x=mid;
        bb->e=z;
        bb=z;
    }
    aa->e=bb->e=NULL;
    st *n=malloc(sizeof(st));
    n->e=NULL;
    st *nn=n;
    ar=ar->e,br=br->e;
 
        while(ar&&br)
        {
            if(ar->x==br->x)
            {
                nn->e=br;
                nn=br;
                ar=ar->e;
                br=br->e;
            }
            else if(ar->x>br->x)
            {
                br=br->e;
            }
            else{ar=ar->e;}
        }
    nn->e=NULL;
    n=n->e;
    if(n)
    while (n)
    {
        printf("%d ",n->x);
        n=n->e;

    }
    else
    printf("NULL");
    return 0;
}