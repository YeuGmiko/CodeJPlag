#include <stdio.h>
#include <stdlib.h>

typedef struct node *PtrToNode;
struct node
{
    int data;
    PtrToNode next;
};

// 创建链表
PtrToNode createList()
{
    PtrToNode head = (PtrToNode)malloc(sizeof(struct node));
    head->next = NULL;
    return head;
}

// 向链表中插入元素
void insert(PtrToNode head, int num)
{
    PtrToNode p = head;
    while (p->next != NULL && p->next->data < num)
    {
        p = p->next;
    }
    if (p->next == NULL || p->next->data > num)
    {
        PtrToNode newNode = (PtrToNode)malloc(sizeof(struct node));
        newNode->data = num;
        newNode->next = p->next;
        p->next = newNode;
    }
}

// 求交集
PtrToNode getIntersection(PtrToNode A, PtrToNode B)
{
    PtrToNode C = createList();
    PtrToNode p1 = A->next, p2 = B->next, p3 = C;
    while (p1 != NULL && p2 != NULL)
    {
        if (p1->data < p2->data)
        {
            p1 = p1->next;
        }
        else if (p1->data == p2->data)
        {
            p3->next = (PtrToNode)malloc(sizeof(struct node));
            p3->next->data = p1->data;
            p3->next->next = NULL;
            p1 = p1->next;
            p2 = p2->next;
            p3 = p3->next;
        }
        else
        {
            p2 = p2->next;
        }
    }
    return C;
}

int main()
{
    PtrToNode A = createList(), B = createList(), C;
    int num;

    // 输入A链表
    scanf("%d", &num);
    while (num != -1)
    {
        insert(A, num);
        scanf("%d", &num);
    }

    // 输入B链表
    scanf("%d", &num);
    while (num != -1)
    {
        insert(B, num);
        scanf("%d", &num);
    }

    // 求交集
    C = getIntersection(A, B);

    // 输出交集
    if (C->next == NULL)
    {
        printf("NULL");
    }
    else
    {
        PtrToNode p = C->next;
        while (p != NULL)
        {
            printf("%d", p->data);
            if (p->next != NULL)
            {
                printf(" ");
            }
            p = p->next;
        }
    }

    return 0;
}