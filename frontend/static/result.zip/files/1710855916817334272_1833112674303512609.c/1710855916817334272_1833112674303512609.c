#include <stdio.h>
#include <stdlib.h>
typedef struct list{
    int num;
    struct list *next;
}List;
List *creative();
List *together(List *head1,List *head2);
int main() {
    int flag=1;
    List *head1,*head2,*head,*p;
    head1=creative();
    head2=creative();
    head=together(head1,head2);
    p=head;
    if(p==NULL){
        printf("NULL");
        return 0;
    }
    while(p){
        List *q=p;
        if(flag){
            printf("%d",p->num);
            flag=0;
        } else{
            printf(" %d",p->num);
        }
        p=p->next;
        free(q);
    }
    return 0;
}
List *creative(){
    int num;
    List *p=NULL,*last,*head=NULL;
    head=NULL;
    while (1){
        scanf("%d",&num);
        if(num>0){
            p=(List*)malloc(sizeof (List));
            p->num=num;
            p->next=NULL;
            if(head!=NULL){
                last->next=p;
            } else{
                head=p;
            }
            last=p;
        } else{
            return head;
        }
    }
}
List *together(List *head1,List *head2){
    List *head=(List*) malloc(sizeof (List)),*p,*last=NULL;
    head->next=NULL;
    while (head1&&head2){
        if(head1->num==head2->num){
            p=(List*) malloc(sizeof (List));
            p->num=head2->num;
            p->next=NULL;
            if(head->next){
                last->next=p;
            } else{
                head->next=p;
            }
            last=p;
            head1=head1->next;
            head2=head2->next;
        } else if(head1->num<head2->num){
            head1=head1->next;
        } else if(head1->num>head2->num){
            head2=head2->next;
        }
    }
    return head->next;
}