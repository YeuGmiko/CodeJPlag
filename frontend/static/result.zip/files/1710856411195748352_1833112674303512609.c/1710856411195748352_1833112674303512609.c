#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node *next;
} Node;

typedef struct {
    Node *head, *tail;
    int len;
} List;

void init(List *l) {
    l->head = l->tail = NULL;
    l->len = 0;
}

void add(List *l, int v) {
    Node *tmp = (Node*)malloc(sizeof(Node));
    tmp->data = v;
    tmp->next = NULL;
    if (l->head == NULL) {
        l->head = tmp;
        l->tail = tmp;
    } else {
        l->tail->next = tmp;
        l->tail = tmp;
    }
    l->len++;
}

Node* common(List *a, List *b) {
    Node *p = (Node*)malloc(sizeof(Node));
    p->next = NULL;
    Node *tail = p;
    Node *ita = a->head;
    Node *itb = b->head;

    while (ita && itb) {
        if (ita->data == itb->data) {
            Node *new = (Node*)malloc(sizeof(Node));
            new->data = ita->data;
            new->next = NULL;
            tail->next = new;
            tail = new;
            ita = ita->next;
            itb = itb->next;
        } else if (ita->data < itb->data) {
            ita = ita->next;
        } else {
            itb = itb->next;
        }
    }
    return p->next; 
}


void print(Node *l) {
    if (l == NULL) {
        printf("NULL\n");
        return;
    }
    Node *it = l;
    while (it) {
        printf("%d", it->data);
        if (it->next != NULL) {
            printf(" ");
        }
        it = it->next;
    }
    printf("\n");
}
int main() {
    List A, B;
    int x, y;
    init(&A);
    while (scanf("%d", &x) && x != -1) {
        add(&A, x);
    }

    init(&B);
    while (scanf("%d", &y) && y != -1) {
        add(&B, y);
    }
    
    Node *C = common(&A, &B);
    print(C);
    
    Node *it = C;
    while (it) {
        Node *tmp = it;
        it = it->next;
        free(tmp);
    }
    it = A.head;
    while (it) {
        Node *tmp = it;
        it = it->next;
        free(tmp);
    }
    it = B.head;
    while (it) {
        Node *tmp = it;
        it = it->next;
        free(tmp);
    }
    return 0;
}
