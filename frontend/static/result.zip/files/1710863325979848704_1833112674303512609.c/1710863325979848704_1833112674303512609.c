#include <stdio.h>  
#include <stdlib.h>  
  
typedef struct Node {  
    int data;  
    struct Node* next;  
} Node;  
  
Node* create(int data) {  
    Node* newNode = (Node*)malloc(sizeof(Node));  
    if (!newNode) {  
        fprintf(stderr, "\n");  
    }  
    newNode->data = data;  
    newNode->next = NULL;  
    return newNode;  
}  
  
  
Node* readList() {  
    Node* head = NULL;  
    Node** tail = &head;  
    int data;  
    while (scanf("%d", &data) && data != -1) {  
        *tail = create(data);  
        tail = &((*tail)->next);  
    }  
    return head;  
}  
  
Node* intersection(Node* S1, Node* S2) {  
    Node* dummy = create(0); 
    Node* tail = dummy; 
      
    while (S1 != NULL && S2 != NULL) {  
        if (S1->data < S2->data) {  
            S1 = S1->next;  
        } else if (S1->data > S2->data) {  
            S2 = S2->next;  
        } else { // S1->data == S2->data  
            tail->next = create(S1->data);  
            tail = tail->next;  
            S1 = S1->next;  
            S2 = S2->next;  
        }  
    }  
      
    tail->next = NULL; 
    Node* result = dummy->next; 
    free(dummy); 
    return result;  
}  
  
void printList(Node* head) {  
    int isFirst = 1;  
    while (head != NULL) {  
        if (!isFirst) printf(" ");  
        isFirst = 0;  
        printf("%d", head->data);  
        head = head->next;  
    }  
    if (isFirst) printf("NULL");   
}  
  
void freeList(Node* head) {  
    Node* temp;  
    while (head != NULL) {  
        temp = head;  
        head = head->next;  
        free(temp);  
    }  
}  
  
int main() {  
    Node* S1 = readList();  
    Node* S2 = readList();  
  
    Node* S3 = intersection(S1, S2);  
  
    printList(S3);  
    printf("\n");  
  
    freeList(S1);  
    freeList(S2);  
    freeList(S3);  
  
    return 0;  
}