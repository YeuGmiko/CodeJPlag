#include <stdio.h>
#include <stdlib.h>

#define MAX_SIZE 100000000

int a[MAX_SIZE];
int b[MAX_SIZE];
int c[MAX_SIZE];

int main()
{
    int n1 = 0, n2 = 0, n3 = 0, tt;
    while (scanf("%d", &tt) == 1 && tt != -1)
    {
        a[n1++] = tt;
    }
    while (scanf("%d", &tt) == 1 && tt != -1)
    {
        b[n2++] = tt;
    }

    int i = 0, j = 0;
    int t = 0;
    while (i < n1 && j < n2)
    {
        if (a[i] == b[j])
        {
            c[n3++] = a[i];
            i++;
            j++;
            t = 1;
        }
        else if (a[i] < b[j])
        {
            i++;
        }
        else
        {
            j++;
        }
    }

    if (!t)
    {
        printf("NULL");
    }
    else
    {
        for (int i = 0; i < n3; i++)
        {
            if (i != n3 - 1)
                printf("%d ", c[i]);
            else
                printf("%d", c[i]);
        }
    }

    return 0;
}