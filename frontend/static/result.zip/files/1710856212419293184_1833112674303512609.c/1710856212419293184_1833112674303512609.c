#include<stdio.h>
 
#include <stdlib.h>
 
struct LNode {
 
    int data;
 
    struct LNode *next;
 
};
 
struct LNode*creatlist()
 
{
 
    struct LNode *p,*t,*head;
 
    int i;
 
    head=(struct LNode *)malloc(sizeof(struct LNode));
 
    t=head;
 
    while(scanf("%d",&i)&&i>=0)
 
    {
 
        p=(struct LNode*)malloc(sizeof(struct LNode));
 
        p->data=i;
 
        p->next =NULL;
 
        t->next=p;
 
        t=p;
 
    }
 
    return head;
 
}
 
 
struct LNode *operate(struct LNode *L1,struct LNode *L2)
{
 	struct LNode *p1,*p2,*p3,*L3;
 
    p1=L1->next;
 
    p2=L2->next ;
 
    L3=(struct LNode*)malloc(sizeof(struct LNode));
 
    L3->next =NULL;
 
    p3=L3;
 	while(p1&&p2)
    {
        	if((p1->data)<(p2->data))
           		p1=p1->next;
        	else if((p1->data)>(p2->data))
            		p2=p2->next;
        	else if((p1->data)==(p2->data))
        	{
         		struct LNode*tail;
         		tail=(struct LNode*)malloc(sizeof(struct LNode));
         		tail->next=NULL;
         		tail->data=p1->data;
         		p3->next=tail;
                p1=p1->next;
                p2=p2->next;
                p3=tail;
            }
 	}
 	return L3;
}
void print(struct LNode *L3)
 
{
 
    struct LNode *p;
 
    p=L3->next;
 
    if(p==NULL)
 
    {
 
        printf("NULL");
 
        return;
 
    }
 
    while(p!=NULL)
 
    {
 
        printf("%d",p->data);
 
        p=p->next;
 
        if(p!=NULL)
            printf(" ");
 
    }
 
}
 
int main()
 
{
 
    struct LNode *L1,*L2,*L3;
 
    L1=creatlist();
 
    L2=creatlist();
 
    L3=operate(L1,L2);
 
    print(L3);
 
    return 0;
 
}