#include<stdio.h>
#include<stdlib.h>
int n;
struct Line
{
    int data;
    struct Line *next;
};
struct Line *creat1()
{
    struct Line *head=NULL,*p1,*p2;
    int i=0;
    do
    {
        p1=(struct Line *)malloc(sizeof(struct Line));
        scanf("%d",&p1->data);
        if(i==0)
        {
            p2=head=p1;
        }
        else
        {
            p2->next=p1;
            p1->next=NULL;
            p2=p1;
        }
        i++;
    }while(p1->data!=-1);
    return(head);
}
 
int main() {
    struct Line *head1, *head2,*head3, *p;
head1=creat1();
head2=creat1();
int same[100],a[100],b[100];
int i=0;
p=head1;
do
{
    a[i]=p->data;
    p=p->next;
    i++;
}while(a[i-1]!=-1);
i=0;
int k=0;
p=head2;
    do
    {
        b[i]=p->data;
        p=p->next;
        i++;
    }while(b[i-1]!=-1);
    int j;
    for(i=0;a[i]!=-1;i++)
    {
        for(j=0;b[j]!=-1;j++)
        {
            if(a[i]==b[j])
            {
                same[k]=a[i];
                k++;
            }
        }
    }
    n=k;       //计算元素个数
    if(k==0)
    {
        printf("NULL");
    }
    else {
        for (i = 0; i < n; i++) {
            printf("%d ", same[i]);
        }
    }
    return 0;
}